<?php
/**
 * @author yupoxiong<i@yufuping.com>
 * Date: 2017/8/27
 */
namespace app\index\controller;

use think\Controller as Tk;

class Controller extends Tk
{

}