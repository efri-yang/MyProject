<?php
/**
 * 用户中心
 * @author yupoxiong<i@yufuping.com>
 * @version 1.0
 * Date: 2017/3/20
 */
namespace app\index\controller;

class User
{
    public function index(){
        return 'user';
    }
}