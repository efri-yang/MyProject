<?php
/**
 * 
 * @author yupoxiong<i@yufuping.com>
 */

namespace app\backend\controller;

use think\Controller as Think;

class Controller extends Think
{
    public function index(){
        return 1;
    }

}