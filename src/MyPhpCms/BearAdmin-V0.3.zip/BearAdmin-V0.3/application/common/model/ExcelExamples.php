<?php
/**
 * 后台管理员模型
 * @author yupoxiong<i@yufuping.com>
 * @version 1.0
 */


namespace app\common\model;

use think\Model;

class ExcelExamples extends Model
{
    protected $name = 'excel_examples';
}
