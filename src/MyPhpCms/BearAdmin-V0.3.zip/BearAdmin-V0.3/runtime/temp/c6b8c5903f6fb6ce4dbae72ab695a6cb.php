<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:79:"D:\php\website\BearAdmin\public/../application/admin\view\admin_menu\index.html";i:1502344400;s:78:"D:\php\website\BearAdmin\public/../application/admin\view\template\layout.html";i:1505908603;s:77:"D:\php\website\BearAdmin\public/../application/admin\view\template\error.html";i:1500443858;s:79:"D:\php\website\BearAdmin\public/../application/admin\view\template\success.html";i:1500443858;s:83:"D:\php\website\BearAdmin\public/../application/admin\view\template\data_header.html";i:1497488411;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="renderer" content="webkit">
    <title><?php echo (isset($web_data['web_title']) && ($web_data['web_title'] !== '')?$web_data['web_title']:"后台管理"); ?></title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="application-name" content="BearAdmin">
    <meta itemprop="name" content="BearAdmin">
    <meta itemprop="image" content="__STATIC__/images/touch-icon-iphone-retina.png">
    <meta name="author" content="于破熊">

    <link rel="apple-touch-icon" href="__STATIC__/images/touch-icon-iphone.png">
    <link rel="apple-touch-icon" sizes="76x76" href="__STATIC__/images/touch-icon-ipad.png">
    <link rel="apple-touch-icon" sizes="120x120" href="__STATIC__/images/touch-icon-iphone-retina.png">
    <link rel="apple-touch-icon" sizes="152x152" href="__STATIC__/images/touch-icon-ipad-retina.png">

    <link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96">

    <link rel="stylesheet" href="__STATIC__/css/app.min.css">
    <script src="__STATIC__/js/app.min.js"></script>
    <link rel="stylesheet" href="__STATIC__/css/skins.css">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script>
        /*数据显示页面相关*/
        var data_del_url = "<?php echo (isset($web_data['data_del_url']) && ($web_data['data_del_url'] !== '')?$web_data['data_del_url']:''); ?>";
        /*定义批量删除id*/
        var del_ids = [];
        function del(id, url) {
            var modal_do_url;
            if (!url) {
                modal_do_url = data_del_url;
            }
            modal_do_url = modal_do_url + "?id=" + id;
            $("#modal_do_url").val(modal_do_url);
            console.log(modal_do_url);
        }

        function del_list(arr, url) {
            var modal_do_url;
            if (!url) {
                modal_do_url = data_del_url;
            }

            modal_do_url = modal_do_url + "?id=" + arr;
            $("#modal_do_url").val(modal_do_url);
        }

        /*删除操作*/
        function modal_do() {
            var url = $("#modal_do_url").val();
            if(url==''){
                return false;
            }
            window.location.href = url;
        }

        /*列表中单个选择和取消*/
        function check_this(obj) {
            var id = $(obj).attr('value');
            if ($(obj).is(':checked')) {
                console.log(id);
                if ($.inArray(id, del_ids) < 0) {
                    del_ids.push(id);
                }
            } else {
                if ($.inArray(id, del_ids) > -1) {
                    del_ids.splice($.inArray(id, del_ids), 1);
                }
            }
            dels(del_ids);
        }
        /*全部选择/取消*/
        function check_all(obj) {
            del_ids = [];
            var all_check = $("input[name='data-checkbox']");
            if ($(obj).is(':checked')) {
                all_check.prop("checked",true);
                $(all_check).each(function () {
                    del_ids.push(this.value);
                });
            }else{
                all_check.prop("checked",false);
            }
            dels(del_ids);
            console.log(del_ids);
        }

        function dels(ids,url) {
            if(del_ids.length<1){
                return false;
            }
            var id_url='';
            var modal_do_url;
            if (!url) {
                modal_do_url = data_del_url;
            }
            modal_do_url = modal_do_url + "?";

            $.each(del_ids,function (index, item) {

                id_url = id_url+"id[]="+item+"&";
            });

            modal_do_url = modal_do_url+id_url;

            $("#modal_do_url").val(modal_do_url);
            console.log(modal_do_url);
        }

        /*数据显示页面相关end*/
    </script>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <header class="main-header">
        <!-- Logo -->
        <a class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b>管理</b>后台</span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b><?php if(!empty($project_name)): ?><?php echo $project_name; endif; ?></b>管理后台</span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">切换导航</span>
            </a>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- User Account: style can be found in dropdown.less -->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="/uploads/admin/avatar/<?php echo $web_data['user_info']['avatar']; ?>" class="user-image"
                                 alt="User Image">
                            <span class="hidden-xs"><?php echo $web_data['user_info']['nick_name']; ?></span>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- User image -->
                            <li class="user-header">
                                <img src="/uploads/admin/avatar/<?php echo $web_data['user_info']['avatar']; ?>" class="img-circle"
                                     alt="User Image">
                                <p>
                                    <?php echo $web_data['user_info']['nick_name']; ?>
                                    <small><?php echo $web_data['user_info']['user_name']; ?></small>
                                </p>
                            </li>
                            <!-- Menu Body -->
                            <li class="user-body">
                                <div class="row">
                                    <div class="col-xs-4 text-center">
                                        <a href="#"></a>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                        <a href="#"></a>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                        <a href="#"></a>
                                    </div>
                                </div>
                                <!-- /.row -->
                            </li>
                            <!-- Menu Footer-->
                            <li class="user-footer">
                                <div class="pull-left">
                                    <a href="<?php echo url('admin_user/profile'); ?>" class="btn btn-default btn-flat">个人资料</a>
                                </div>
                                <div class="pull-right">
                                    <a href="<?php echo url('pub/logout'); ?>" class="btn btn-default btn-flat">退出</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a data-toggle="control-sidebar"><i class="fa fa-cog"></i></a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="__AVATAR__<?php echo $web_data['user_info']['avatar']; ?>" class="img-circle" alt="User Image">
                </div>
                <div class="pull-left info">
                    <p><?php if(!empty($user_info['user_name'])): ?><?php echo $user_info['user_name']; endif; ?></p>
                    <a><i class="fa fa-circle text-success"></i> 正常</a>
                </div>
            </div>

            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu">
                <?php echo $web_data['left_menu']; ?>
            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <?php echo $web_data['web_title']; ?>
            </h1>
            <ol class="breadcrumb">
                <?php if(isset($web_data['current_nav']) && !empty($web_data['current_nav'])): ?>
                <li><a href="<?php echo url('admin/index/index'); ?>"><i class="fa fa-home"></i> 主页</a></li>
                <?php echo $web_data['current_nav']; endif; ?>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <?php if(\think\Session::get('error_message')): ?>
            <div id="error_message" class="alert alert-danger alert-dismissible admin-do-alert">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h4><i class="icon fa fa-ban"></i> 错误提示!</h4>
    <?php if(\think\Session::get('error_message')): ?>
    <?php echo \think\Session::get('error_message'); endif; ?>
</div>
<script>
    var msg = $('#error_message');
    msg.delay(500).fadeIn();
    msg.delay(3000).fadeOut();
</script>
            <?php endif; if(\think\Session::get('success_message')): ?>
            <div id="success_message" class="alert alert-success alert-dismissible admin-do-alert">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h4><i class="icon fa fa-check"></i> 成功提示!</h4>
    <?php if(\think\Session::get('success_message')): ?>
    <?php echo \think\Session::get('success_message'); endif; ?>
</div>
<script>
    var msg = $('#success_message');
    msg.delay(500).fadeIn();
    msg.delay(3000).fadeOut();
</script>
            <?php endif; ?>
            <div class="row">
    <div class="col-md-12">
        <div class="box">
            <!--数据列表页头部-->
            <div class="box-header">
    <h3 class="box-title"><?php echo $web_data['web_title']; ?></h3>
    <?php if(isset($total)): ?>
    共<?php echo $total; ?>条记录
    <?php endif; ?>
    <div class="box-tools">
        <div class="input-group input-group-sm">
            <div class="input-group-btn">
                <a href="<?php echo $web_data['data_add_url']; ?>" class="btn btn-default pull-right">
                    <i class="fa fa-plus"></i>
                    <?php echo $web_data['data_add_title']; ?>
                </a>
            </div>
        </div>
    </div>
</div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover table-bordered">
                    <tbody>
                    <tr>
                        <th>ID</th>
                        <th>菜单名称</th>
                        <th>url</th>
                        <th>父级ID</th>
                        <th>图标</th>
                        <th>排序</th>
                        <th>状态</th>
                        <th>日志记录方式</th>
                        <th>操作</th>
                    </tr>
                    <?php echo $menu_list; ?>

                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <div>


                </div>
            </div>
        </div>
        <!-- /.box -->
    </div>
</div>

        </section>
        <!-- /.content -->
    </div>

    <!--删除操作modal-->
    <div class="modal fade" id="modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span></button>
                    <h4 class="modal-title">提示</h4>
                </div>
                <div class="modal-body">
                    <p id="modal_message">您确认执行本次操作吗？</p>
                    <input name="modal_do_url" id="modal_do_url" value="" placeholder="modal_do_url" type="hidden">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">取消</button>
                    <button onclick="modal_do()" type="button" class="btn btn-primary">确认</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!--/.删除操作modal-->

    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>V</b> 1.0
        </div>
        <strong>Copyright &copy; 2017 <a></a>.</strong> All rights
        reserved.
    </footer>


    <aside class="control-sidebar control-sidebar-dark">
        <div class="tab-content">
            <div class="tab-pane" id="control-sidebar-home-tab">
            </div>
        </div>
    </aside>
    <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->
<script src="__STATIC__/js/demo.js" type="text/javascript"></script>
<script>
    console.log('%c BUG？反馈->%c i@yufuping.com',';color:#1e90ff',';color:#070cfe');
</script>
</body>
</html>
<script>
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?d740981d25ee4b445e195a1e4a37630b";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();
</script>