<?php
/**
 * Appkey类，目前用于取值
 *
 */

namespace appkey;

class Appkey
{
    public static function getAppkey()
    {
        

    }
}
